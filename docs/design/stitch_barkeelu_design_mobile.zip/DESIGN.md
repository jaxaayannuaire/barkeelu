---
name: Dignified Solidarity
colors:
  surface: '#fbf8ff'
  surface-dim: '#dcd9e0'
  surface-bright: '#fbf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f5f2fa'
  surface-container: '#f0edf4'
  surface-container-high: '#eae7ee'
  surface-container-highest: '#e4e1e8'
  on-surface: '#1b1b20'
  on-surface-variant: '#474554'
  inverse-surface: '#303035'
  inverse-on-surface: '#f3eff7'
  outline: '#777586'
  outline-variant: '#c8c4d7'
  surface-tint: '#5448d4'
  primary: '#493bc8'
  on-primary: '#ffffff'
  primary-container: '#6257e2'
  on-primary-container: '#f0ecff'
  inverse-primary: '#c5c0ff'
  secondary: '#845400'
  on-secondary: '#ffffff'
  secondary-container: '#ffa501'
  on-secondary-container: '#684100'
  tertiary: '#844200'
  on-tertiary: '#ffffff'
  tertiary-container: '#a85600'
  on-tertiary-container: '#ffebdf'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e3dfff'
  primary-fixed-dim: '#c5c0ff'
  on-primary-fixed: '#130068'
  on-primary-fixed-variant: '#3b2bbb'
  secondary-fixed: '#ffddb6'
  secondary-fixed-dim: '#ffb95b'
  on-secondary-fixed: '#2a1800'
  on-secondary-fixed-variant: '#643f00'
  tertiary-fixed: '#ffdcc5'
  tertiary-fixed-dim: '#ffb783'
  on-tertiary-fixed: '#301400'
  on-tertiary-fixed-variant: '#703700'
  background: '#fbf8ff'
  on-background: '#1b1b20'
  surface-variant: '#e4e1e8'
  brand-primary-hover: '#5146CE'
  brand-primary-soft: '#EFEDFF'
  brand-secondary-hover: '#E89200'
  brand-secondary-soft: '#FFF4DC'
  brand-symbol-green: '#39C43A'
  neutral-950: '#17171C'
  neutral-700: '#4E4D58'
  neutral-500: '#777582'
  neutral-300: '#D8D6E0'
  neutral-100: '#F5F4F8'
  neutral-0: '#FFFFFF'
  status-info: '#2563EB'
  status-success: '#168A48'
  status-warning: '#B86A00'
  status-neutral: '#64748B'
  status-danger: '#C73535'
typography:
  display-lg:
    fontFamily: Epilogue
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Epilogue
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Epilogue
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.015em
  headline-lg-mobile:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Epilogue
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Epilogue
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  title-md:
    fontFamily: Epilogue
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Epilogue
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
  body-md:
    fontFamily: Epilogue
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 22px
  label-lg:
    fontFamily: Epilogue
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Epilogue
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
  caption:
    fontFamily: Epilogue
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-md: 1.5rem
  gutter-lg: 2rem
  margin: 1rem
  margin-md: 1.5rem
  margin-lg: 3rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
---

# Barkeelu — Design System UI/UX

**Version :** 1.0 (Stabilisée finale)  
**Statut :** Spécification de référence de production  
**Périmètre :** Site public, parcours de don, espaces utilisateurs et administration  
**Principes directeurs :** Simplicité, dignité, rigueur factuelle, sobriété, ancrage local (Sénégal & Diaspora).

---

## 1. Principes produit & Vérité de l’information

Barkeelu privilégie la clarté, l'éthique et la confiance fondée sur des faits concrets.
- **Interdictions strictes :** Exclusion totale des termes « certifié », « garantie de versement », « 100% sécurisé », « 100 % sécurisé », « sans frais cachés », « validation sous 24h », « paiement instantané », « transparence totale », « dons anonymes & reçus », « 2025 », « #493BC8 », « Plus Jakarta ».
- **Formulations autorisées et prudentes :**
  - « Campagnes examinées avant publication »
  - « Identité du bénéficiaire vérifiée selon le niveau applicable »
  - « Frais présentés avant confirmation »
  - « Paiement confirmé après vérification par le serveur »
  - « Décaissement soumis aux contrôles applicables »
- **Données de démonstration :** Toute maquette ou vue de démonstration doit afficher explicitement : *« Maquette — contenus et données fictifs »*.
- **Distinction stricte :** Vérification documentaire, KYC, avis et métriques de collecte sont des concepts distincts.

---

## 2. Identité visuelle & Logos

### 2.1 Utilisation des logos
- **Desktop (en-tête & footer) :** Utiliser exclusivement le logo horizontal officiel `logo_barkeelu_h200_fb.png` ({{DATA:IMAGE:IMAGE_9}}). Ne jamais ajouter le mot textuel « Barkeelu » à côté du logo car il est déjà intrinsèquement calligraphié dans le fichier.
- **Mobile compact :** Utiliser le logo carré `favicon-barkeelu-2.png` ({{DATA:IMAGE:IMAGE_10}}).
- **Intégrité :** Respecter strictement les proportions d'origine (aucun étirement, recadrage, recoloration ni filtre).

### 2.2 Palette chromatique

| Jeton | Valeur HEX | Rôle & Usage strict |
|---|---:|---|
| `primary` | `#6257E2` | Couleur d'action principale exclusive (CTA primaire, focus, barres de progression) |
| `primary-container` | `#6257E2` | Conteneur principal pour composants majeurs |
| `brand-primary-hover` | `#5146CE` | État survol / pressé du CTA primaire |
| `brand-primary-soft` | `#EFEDFF` | Fonds doux de mise en valeur et sélections |
| `brand-secondary` | `#FEA500` | Accent secondaire chaleureux (mises en avant d'urgence, badges secondaires) |
| `brand-secondary-hover` | `#E89200` | État survol de l'accent |
| `brand-secondary-soft` | `#FFF4DC` | Fonds légers d'accent |
| `brand-symbol-green` | `#39C43A` | **Vert patrimonial du symbole du logo uniquement.** Strictement interdit hors du symbole logo. |

### 2.3 Neutres et Couleurs d'état

| Jeton | Valeur HEX | Usage |
|---|---:|---|
| `neutral-950` | `#17171C` | Titres et texte à fort contraste (WCAG AAA) |
| `neutral-700` | `#4E4D58` | Corps de texte courant |
| `neutral-500` | `#777582` | Métadonnées, libellés secondaires |
| `neutral-300` | `#D8D6E0` | Bordures, séparateurs |
| `neutral-100` | `#F5F4F8` | Surfaces de cartes et fonds de formulaires |
| `neutral-0` | `#FFFFFF` | Surfaces de fond pures |
| `status-info` | `#2563EB` | Information, statut « Examen en cours » |
| `status-success`| `#168A48` | Validation confirmée (distinct du vert logo) |
| `status-warning`| `#B86A00` | Statut « Informations à compléter » |
| `status-neutral`| `#64748B` | Statut « Non vérifié » |
| `status-danger` | `#C73535` | Erreur, refus ou action destructive |

---

## 3. Typographie

- **Famille typographique unique :** **Kodchasan** (Google Fonts).
- **Interdiction formelle :** Suppression intégrale de « Plus Jakarta Sans » et de toute règle `!important` globale.
- **Graisses normées :**
  - `Kodchasan 500` (Medium) : texte courant, champs de saisie, métadonnées, paragraphes.
  - `Kodchasan 600` (SemiBold) : titres (H1 à H4), boutons et CTA majeurs.
- **Configuration Tailwind :**
  - `display`: ["Kodchasan", "system-ui", "sans-serif"]
  - `headline`: ["Kodchasan", "system-ui", "sans-serif"]
  - `title`: ["Kodchasan", "system-ui", "sans-serif"]
  - `body`: ["Kodchasan", "system-ui", "sans-serif"]
  - `label`: ["Kodchasan", "system-ui", "sans-serif"]
  - `caption`: ["Kodchasan", "system-ui", "sans-serif"]
- **Chiffres tabulaires :** Obligatoires pour l'alignement des montants financiers en FCFA (`tabular-nums`).

---

## 4. Règles de moyens de paiement & devises

- **Devise de l'interface :** Toujours libellée **FCFA** dans l'UI utilisateur (et `XOF` dans les contrats techniques/API).
- **Moyens de paiement :**
  - Mention réglementaire unique autorisée : *« Wave prioritaire — autres moyens prévus ultérieurement. »*
  - Orange Money, Visa, Mastercard ne sont pas mentionnés comme disponibles.

---

## 5. Composants UI & Règles ergonomiques

- **Rayons de courbure :**
  - Contrôles, boutons et champs de formulaires : **10 px** (`rounded-[10px]`).
  - Cartes de campagne et encadrés : **16 px** (`rounded-[16px]`).
  - Blocs éditoriaux majeurs : **24 px** (`rounded-[24px]`).
- **Cibles tactiles :** 44 × 44 px minimum.
- **Badges de statut standardisés :**
  - « Identité vérifiée »
  - « Examen en cours »
  - « Informations à compléter »
  - « Non vérifié »
- **Navigation mobile :** 4 onglets tactiles inférieurs avec icônes SVG inline : *Accueil*, *Découvrir*, *Rechercher*, *Compte*.
- **Footer :** Mention légale unifiée : *« © 2026 Barkeelu.com. Tous droits réservés. »*. Liens autorisés : À propos, Comment ça marche, Sécurité et vérification, Conditions générales, Confidentialité, Mentions légales, Aide en ligne.
